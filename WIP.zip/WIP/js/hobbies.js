const hobbiesArray = [
    { name: 'volleyball', lengthInYearsAtHobby: 25 },
    { name: 'cooking', lengthInYearsAtHobby: 15},
    { name: 'swimming', lengthInYearsAtHobby: 11}
];

function printHobbyInfo(hobby){
    console.log(` ${hobby.name} enjoyed for ${hobby.lengthInYearsAtHobby} `)
}

for (let hobby of hobbiesArray){
    printHobbyInfo(hobby);
}


let band1 = {
    name : "Pink Floyd",
    city : "London" ,
    country : "England",
    yearFormed : 1965,
    genres : ["Progressive rock", "psychedelic rock", "art rock"]
}
band1.genres = new Array("Progressive rock2", "psychedelic rock2", "art rock2");

let band2 = {
    name : "The Who",
    city : "London" ,
    country : "England",
    yearFormed : 1964,
    genres : ["English folk rock", "art rock"]
}

let bands = [band1, band2];

for(let band of bands){
    console.log("Band name: " + band.name + " formed in " + band.yearFormed);
}
