let hobbiesArray = ['coding',
'testing',
'listening to music'];

function printHobbies(hobbies){
    console.log("I like " + hobbies.length + " things:");
    for(let i = 0; i < hobbiesArray.length; i++){
        console.log(`I like ${hobbiesArray[i]}`);
    }
}

printHobbies(hobbiesArray);

myColor = ["Red", "Green", "White", "Black"]; 
let str = myColor.join(",");
console.log(str);