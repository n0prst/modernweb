function displayName(nam){
    console.log("Hello, " + nam);
}
displayName("Alex");