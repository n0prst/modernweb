let x, y, z;

x=10;
y='10';
z=30;

console.log(`x is ${typeof x}`);

var newX = x++;
console.log(`newX is ${typeof newX}`);
console.log(`comparison x==y ${x==y}`);

let timeInMs = Date.now();
console.log('time = ' + timeInMs);