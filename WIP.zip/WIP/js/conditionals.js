let numOne = 1;
let stringOne = '1';

console.log('double ==', numOne == stringOne);
console.log('triple ===', numOne === stringOne);

const day = new Date().getDay();

console.log("Today is " + day);

let mess;

if(day == 1) mess = "Back to work!"
else if(day == 3) mess = "Over the hump!"
else if(day>5) mess = "It is the weekend!"
else mess = "It is a weekday";
console.log("Message: " + mess);